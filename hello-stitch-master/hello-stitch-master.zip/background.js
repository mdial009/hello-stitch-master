// filepath: c:\Users\diallo_madany\Downloads\hello-friend-master\hello-friend-master\background.js
chrome.runtime.onInstalled.addListener(() => {
  console.log("Hello Stitch extension installed");
});
