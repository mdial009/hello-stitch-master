const columns = [];

// Expanded mock data for testing with Live Server
const mockBookmarks = [
  {
    title: "Bookmarks Bar",
    children: [
      {
        title: "Google",
        url: "https://www.google.com",
      },
      {
        title: "GitHub",
        url: "https://www.github.com",
      },
      {
        title: "Stack Overflow",
        url: "https://stackoverflow.com",
      },
      {
        title: "MDN Web Docs",
        url: "https://developer.mozilla.org",
      },
      {
        title: "Folder 1",
        children: [
          {
            title: "Sub Google",
            url: "https://www.google.com",
          },
          {
            title: "Sub GitHub",
            url: "https://www.github.com",
          },
          ...Array.from({ length: 98 }, (_, i) => ({
            title: `Sub Bookmark ${i + 1}`,
            url: `https://example.com/sub/${i + 1}`,
          })),
        ],
      },
      {
        title: "Folder 2",
        children: [
          {
            title: "Sub Stack Overflow",
            url: "https://stackoverflow.com",
          },
          {
            title: "Sub MDN Web Docs",
            url: "https://developer.mozilla.org",
          },
          ...Array.from({ length: 98 }, (_, i) => ({
            title: `Sub Bookmark ${i + 1}`,
            url: `https://example.com/sub/${i + 1}`,
          })),
        ],
      },
      ...Array.from({ length: 90 }, (_, i) => ({
        title: `Bookmark ${i + 1}`,
        url: `https://example.com/${i + 1}`,
      })),
    ],
  },
  {
    title: "Other Bookmarks",
    children: [
      {
        title: "YouTube",
        url: "https://www.youtube.com",
      },
      {
        title: "Reddit",
        url: "https://www.reddit.com",
      },
      {
        title: "Folder 3",
        children: [
          {
            title: "Sub YouTube",
            url: "https://www.youtube.com",
          },
          {
            title: "Sub Reddit",
            url: "https://www.reddit.com",
          },
          ...Array.from({ length: 98 }, (_, i) => ({
            title: `Sub Bookmark ${i + 1}`,
            url: `https://example.com/sub/${i + 1}`,
          })),
        ],
      },
      ...Array.from({ length: 90 }, (_, i) => ({
        title: `Other Bookmark ${i + 1}`,
        url: `https://example.com/other/${i + 1}`,
      })),
    ],
  },
];

function processBookmarks(tree) {
  const columns = [];
  function visit(node, path = []) {
    if (node.url) {
      columns.push({
        title: node.title,
        url: node.url,
        path: path.slice(1), // skip root
      });
    }
    if (node.children) {
      node.children.forEach((child) => visit(child, path.concat(node.title)));
    }
  }
  visit(tree[0]);
  return [{ title: "Bookmarks", children: columns }];
}

const updateTimestamp = () => {
  const now = new Date();
  const hours = now.getHours().toString().padStart(2, "0");
  const minutes = now.getMinutes().toString().padStart(2, "0");
  const seconds = now.getSeconds().toString().padStart(2, "0");
  const month = (now.getMonth() + 1).toString().padStart(2, "0");
  const day = now.getDate().toString().padStart(2, "0");
  const year = now.getFullYear();
  const ampm = hours >= 12 ? "PM" : "AM";
  const formattedHours = (hours % 12 || 12).toString().padStart(2, "0");
  const date = `${month}/${day}/${year}`;
  const time = `${formattedHours}:${minutes}:${seconds} ${ampm}`;
  document.getElementById("hours").innerText = formattedHours;
  document.getElementById("minutes").innerText = minutes;
  document.getElementById("seconds").innerText = seconds;
  document.getElementById("ampm").innerText = ampm;
  document.getElementById("date").innerText = date;
};

document.addEventListener("DOMContentLoaded", () => {
  document.body.style.background = options.BACKGROUND;
  document.getElementById("welcome").style.color = options.TITLE_COLOR;
  document.getElementById("welcome").innerText = options.TITLE;
  console.log("DOMContentLoaded event fired"); // Debug log

  // Use mock data for testing with Live Server
  const processedBookmarks = processBookmarks(mockBookmarks);
  console.log("Processed Bookmarks:", processedBookmarks);

  // Update the timestamp
  updateTimestamp();
  setInterval(updateTimestamp, 1000); // Update the timestamp every second
});

// notify firefox users to set their home page
if (window.browser) {
  window.browser.runtime.getBrowserInfo().then((browser) => {
    if (browser.name === "Firefox") {
      console.log(
        `Hello, friend. On ${browser.name} you can make this your home page by setting the following URL in your home page preferences:`
      );
      console.log(window.location.href);
    }
  });
}
